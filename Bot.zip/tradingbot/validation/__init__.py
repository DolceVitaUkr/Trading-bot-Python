# file: tradingbot/validation/__init__.py
# module_version: v1.00

"""
Validation subsystem - Strategy validation and promotion gate.
Only validation modules decide strategy promotion.
"""