# file: tradingbot/brokers/exchange.py

class ExchangeAPI:
    """Placeholder for a generic exchange API interface."""
    pass
