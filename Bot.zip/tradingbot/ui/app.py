"""Minimal FastAPI application for controlling the bot."""

from __future__ import annotations

import asyncio
from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
import os
from datetime import datetime

from tradingbot.core.runtime_controller import RuntimeController
from tradingbot.core.validation_manager import ValidationManager
try:
    from tradingbot.core.pair_manager import PairManager
except ImportError:
    # Fallback if pair_manager not available
    PairManager = None
try:
    from tradingbot.core.strategy_development_manager import StrategyDevelopmentManager
    strategy_manager = StrategyDevelopmentManager()
except ImportError:
    strategy_manager = None
try:
    print("[INFO] Importing ExchangeBybit...")
    from tradingbot.brokers.exchangebybit import ExchangeBybit
    print("[SUCCESS] ExchangeBybit imported successfully")
except ImportError as e:
    ExchangeBybit = None
    print(f"[WARNING] ExchangeBybit not available - {e}")
except Exception as e:
    ExchangeBybit = None
    print(f"[ERROR] Error importing ExchangeBybit: {e}")
    import traceback
    traceback.print_exc()
try:
    from tradingbot.core.paper_trader import get_paper_trader
except ImportError:
    get_paper_trader = None

try:
    from tradingbot.core.trading_engine import trading_engine
except ImportError:
    trading_engine = None
    print("Trading engine not available")

from .routes.validation import router as validation_router
from .routes.diff import router as diff_router

import re


def should_log_activity(source: str, message: str) -> bool:
    """Filter to only log important activities."""
    # Important keywords to always log
    important_keywords = [
        'started', 'stopped', 'connected', 'disconnected', 'error', 
        'trade', 'position', 'closed', 'opened', 'executed',
        'paper trading started', 'paper trading stopped'
    ]
    
    # Skip repetitive wallet balance checks
    skip_patterns = [
        r'wallet connected.*Balance',
        r'Testing.*API connection',
        r'Fetching wallet balance',
        r'Successfully fetched wallet balance'
    ]
    
    message_lower = message.lower()
    
    # Skip if matches skip patterns
    for pattern in skip_patterns:
        if re.search(pattern, message, re.IGNORECASE):
            return False
    
    # Log if contains important keywords
    for keyword in important_keywords:
        if keyword in message_lower:
            return True
    
    return False


runtime = RuntimeController()
validator = ValidationManager()
pair_manager = PairManager() if PairManager else None

# Activity tracking - Import from centralized logger
from ..core.activity_logger import activity_log, log_activity as _log_activity
from ..core.background_tasks import background_tasks
from datetime import datetime

def log_activity(source: str, message: str, activity_type: str = "info"):
    """Add activity to the log."""
    # Only log important activities
    if not should_log_activity(source, message):
        return
    # Use centralized logger
    _log_activity(source, message, activity_type)

# Initialize exchange connectors
bybit_crypto = None
bybit_futures = None
ibkr_connection_manager = None

if ExchangeBybit:
    try:
        print("[INFO] Initializing Bybit connections...")
        bybit_crypto = ExchangeBybit("CRYPTO_SPOT", "live")
        print("[SUCCESS] Bybit Crypto connection initialized")
        log_activity("BYBIT", "Crypto Spot connection initialized", "success")
        bybit_futures = ExchangeBybit("CRYPTO_FUTURES", "live")
        print("[SUCCESS] Bybit Futures connection initialized")
        log_activity("BYBIT", "Crypto Futures connection initialized", "success")
    except Exception as e:
        print(f"[ERROR] Warning: Could not initialize Bybit connections: {e}")
        print(f"[ERROR] This means live trading will not be available")
        print(f"[ERROR] Error details: {e}")
        import traceback
        traceback.print_exc()

# Initialize IBKR connection manager
try:
    from tradingbot.brokers.connectibkrapi import IBKRConnectionManager
    print("[INFO] Initializing IBKR connection manager...")
    ibkr_connection_manager = IBKRConnectionManager()
    print("[SUCCESS] IBKR connection manager initialized")
except Exception as e:
    print(f"[ERROR] Warning: Could not initialize IBKR connection manager: {e}")
    print(f"[ERROR] IBKR trading will not be available")


def create_app() -> FastAPI:
    app = FastAPI()
    
    # Get the directory path for templates and static files
    ui_dir = os.path.dirname(os.path.abspath(__file__))
    templates_dir = os.path.join(ui_dir, "templates")
    static_dir = os.path.join(ui_dir, "static")
    
    # Setup templates and static files
    templates = Jinja2Templates(directory=templates_dir)
    app.mount("/static", StaticFiles(directory=static_dir), name="static")
    
    # Include route modules
    app.include_router(validation_router)
    app.include_router(diff_router)
    
    @app.get("/", response_class=HTMLResponse)
    def dashboard(request: Request):
        return templates.TemplateResponse("dashboard-v2.html", {"request": request})
    
    @app.get("/old", response_class=HTMLResponse)
    def old_dashboard(request: Request):
        return templates.TemplateResponse("dashboard.html", {"request": request})

    @app.get("/status")
    def status():
        return runtime.get_state()

    @app.post("/live/{asset}/enable")
    def enable(asset: str):
        # Input validation
        if not asset or not asset.strip():
            raise HTTPException(status_code=400, detail="Asset symbol cannot be empty")
        if len(asset) > 20:
            raise HTTPException(status_code=400, detail="Asset symbol too long")
        if not asset.replace("/", "").replace("-", "").isalnum():
            raise HTTPException(status_code=400, detail="Invalid asset symbol format")
        
        try:
            runtime.enable_live(asset.upper().strip())
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"asset": asset.upper().strip(), "live": True}

    @app.post("/live/{asset}/disable")
    def disable(asset: str):
        # Input validation
        if not asset or not asset.strip():
            raise HTTPException(status_code=400, detail="Asset symbol cannot be empty")
        if len(asset) > 20:
            raise HTTPException(status_code=400, detail="Asset symbol too long")
        if not asset.replace("/", "").replace("-", "").isalnum():
            raise HTTPException(status_code=400, detail="Invalid asset symbol format")
        
        try:
            runtime.disable_live(asset.upper().strip())
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"asset": asset.upper().strip(), "live": False}

    @app.post("/paper/{asset}/enable")
    def enable_paper(asset: str):
        """Enable paper trading for an asset."""
        # Input validation
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        
        try:
            # Get the paper trader for this asset
            if get_paper_trader:
                paper_trader = get_paper_trader(asset)
                if paper_trader:
                    # Start paper trading
                    if hasattr(paper_trader, 'start_trading'):
                        paper_trader.start_trading()
                    paper_trader.is_active = True
                    
                    # Update runtime state
                    state = runtime.get_state()
                    if 'paper_trading' not in state:
                        state['paper_trading'] = {}
                    state['paper_trading'][asset] = {'enabled': True, 'status': 'running'}
                    
                    return {"asset": asset, "paper": True, "status": "enabled"}
            
            raise HTTPException(status_code=500, detail=f"Paper trader not available for {asset}")
            
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to enable paper trading: {str(exc)}")
    
    @app.post("/paper/{asset}/disable")
    def disable_paper(asset: str):
        """Disable paper trading for an asset."""
        # Input validation
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        
        try:
            # Get the paper trader for this asset
            if get_paper_trader:
                paper_trader = get_paper_trader(asset)
                if paper_trader:
                    # Stop paper trading
                    if hasattr(paper_trader, 'stop_trading'):
                        paper_trader.stop_trading()
                    paper_trader.is_active = False
                    
                    # Update runtime state
                    state = runtime.get_state()
                    if 'paper_trading' not in state:
                        state['paper_trading'] = {}
                    state['paper_trading'][asset] = {'enabled': False, 'status': 'stopped'}
                    
                    return {"asset": asset, "paper": False, "status": "disabled"}
            
            raise HTTPException(status_code=500, detail=f"Paper trader not available for {asset}")
            
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to disable paper trading: {str(exc)}")

    @app.post("/kill/global/{onoff}")
    def kill(onoff: str):
        # Input validation for kill switch
        if not onoff or not onoff.strip():
            raise HTTPException(status_code=400, detail="Kill switch value cannot be empty")
        onoff_clean = onoff.strip().lower()
        if onoff_clean not in ["on", "off", "true", "false", "1", "0"]:
            raise HTTPException(status_code=400, detail="Kill switch must be 'on', 'off', 'true', 'false', '1', or '0'")
        
        kill_enabled = onoff_clean in ["on", "true", "1"]
        try:
            runtime.set_global_kill(kill_enabled)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to set kill switch: {exc}") from exc
        return {"kill_switch": runtime.get_state()["global"]["kill_switch"]}

    async def get_historical_changes(exchange, symbol, current_price):
        """Get historical price changes for 1h and 4h intervals."""
        try:
            from datetime import datetime, timedelta
            
            # Get current time
            now = datetime.now()
            
            # Get 1h kline data
            kline_1h = await exchange.client.get_kline(
                category="spot",
                symbol=symbol,
                interval="60",  # 1 hour in minutes
                start=int((now - timedelta(hours=2)).timestamp() * 1000),
                end=int(now.timestamp() * 1000),
                limit=2
            )
            
            # Get 4h kline data  
            kline_4h = await exchange.client.get_kline(
                category="spot",
                symbol=symbol,
                interval="240",  # 4 hours in minutes
                start=int((now - timedelta(hours=5)).timestamp() * 1000),
                end=int(now.timestamp() * 1000),
                limit=2
            )
            
            # Calculate changes
            change_1h = 0
            change_4h = 0
            
            if kline_1h and kline_1h.get('result', {}).get('list'):
                klines = kline_1h['result']['list']
                if len(klines) >= 2:
                    # Klines are in reverse order (newest first)
                    open_price_1h = float(klines[-1][1])  # Open price of older candle
                    if open_price_1h > 0:
                        change_1h = ((current_price - open_price_1h) / open_price_1h) * 100
            
            if kline_4h and kline_4h.get('result', {}).get('list'):
                klines = kline_4h['result']['list']
                if len(klines) >= 2:
                    open_price_4h = float(klines[-1][1])  # Open price of older candle
                    if open_price_4h > 0:
                        change_4h = ((current_price - open_price_4h) / open_price_4h) * 100
            
            return {
                'change_1h': change_1h,
                'change_4h': change_4h
            }
            
        except Exception as e:
            print(f"Error getting historical changes for {symbol}: {e}")
            return {
                'change_1h': 0,
                'change_4h': 0
            }

    @app.get("/pairs/top")
    async def get_top_pairs():
        """Get top trading pairs from Bybit with real-time analysis."""
        try:
            if not bybit_crypto:
                raise HTTPException(status_code=503, detail="Bybit connection not available")
            
            # Get tickers data from Bybit
            from datetime import datetime, timedelta
            import asyncio
            
            # Get all USDT perpetual tickers
            tickers_response = await bybit_crypto.client.get_tickers(category="spot")
            
            if not tickers_response or tickers_response.get('retCode') != 0:
                raise Exception("Failed to fetch tickers from Bybit")
            
            tickers = tickers_response.get('result', {}).get('list', [])
            
            # Filter for USDT pairs and calculate metrics
            usdt_pairs = []
            tasks = []
            
            # Top symbols to analyze (most liquid)
            top_symbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 
                          'ADAUSDT', 'DOGEUSDT', 'MATICUSDT', 'DOTUSDT', 'AVAXUSDT',
                          'LINKUSDT', 'UNIUSDT', 'ATOMUSDT', 'LTCUSDT', 'NEARUSDT']
            
            for ticker in tickers:
                symbol = ticker.get('symbol', '')
                if symbol in top_symbols:
                    # Collect current data
                    current_price = float(ticker.get('lastPrice', 0))
                    volume_24h = float(ticker.get('volume24h', 0)) * current_price  # Convert to USD
                    change_24h = float(ticker.get('price24hPcnt', 0)) * 100  # Convert to percentage
                    
                    # Get kline data for 1h and 4h changes
                    tasks.append(get_historical_changes(bybit_crypto, symbol, current_price))
                    
                    usdt_pairs.append({
                        'symbol': symbol.replace('USDT', '/USDT'),
                        'price': current_price,
                        'volume24h': volume_24h,
                        'change24h': change_24h,
                        'bid': float(ticker.get('bid1Price', 0)),
                        'ask': float(ticker.get('ask1Price', 0))
                    })
            
            # Get historical changes for all pairs
            if tasks:
                historical_data = await asyncio.gather(*tasks)
                for i, hist_data in enumerate(historical_data):
                    usdt_pairs[i].update(hist_data)
            
            # Calculate scores and rank pairs
            scored_pairs = []
            for pair in usdt_pairs:
                # Calculate spread in basis points
                if pair['bid'] > 0 and pair['ask'] > 0:
                    spread_bps = ((pair['ask'] - pair['bid']) / pair['price']) * 10000
                else:
                    spread_bps = 0
                
                # Calculate momentum score based on changes
                momentum_score = (
                    pair.get('change_1h', 0) * 0.5 +
                    pair.get('change_4h', 0) * 0.3 +
                    pair['change24h'] * 0.2
                )
                
                # Volume score (normalized)
                volume_score = min(100, (pair['volume24h'] / 1000000) * 0.1)  # Per million USD
                
                # Volatility score based on price changes
                volatility = abs(pair.get('change_1h', 0)) + abs(pair.get('change_4h', 0)) + abs(pair['change24h'])
                volatility_score = min(100, volatility * 10)
                
                # Trend strength
                if pair.get('change_1h', 0) > 0 and pair.get('change_4h', 0) > 0 and pair['change24h'] > 0:
                    trend_strength = min(1.0, (pair.get('change_1h', 0) + pair.get('change_4h', 0) + pair['change24h']) / 10)
                elif pair.get('change_1h', 0) < 0 and pair.get('change_4h', 0) < 0 and pair['change24h'] < 0:
                    trend_strength = max(-1.0, (pair.get('change_1h', 0) + pair.get('change_4h', 0) + pair['change24h']) / 10)
                else:
                    trend_strength = 0
                
                # Determine regime
                if abs(trend_strength) > 0.5:
                    regime = "trending"
                elif volatility_score > 50:
                    regime = "volatile"
                elif spread_bps < 10 and volume_score > 50:
                    regime = "liquid"
                else:
                    regime = "ranging"
                
                # Overall score
                score = (
                    volume_score * 0.3 +
                    abs(momentum_score) * 0.3 +
                    volatility_score * 0.2 +
                    (100 - spread_bps) * 0.2
                )
                
                scored_pairs.append({
                    "symbol": pair['symbol'],
                    "price": round(pair['price'], 8),
                    "volume24h": round(pair['volume24h'], 2),
                    "change24h": round(pair['change24h'], 2),
                    "change_1h": round(pair.get('change_1h', 0), 2),
                    "change_4h": round(pair.get('change_4h', 0), 2),
                    "score": round(score, 1),
                    "regime": regime,
                    "spread_bps": round(spread_bps, 1),
                    "momentum_score": round(abs(momentum_score), 1),
                    "volume_score": round(volume_score, 1),
                    "volatility_score": round(volatility_score, 1),
                    "trend_strength": round(trend_strength, 2)
                })
            
            # Sort by score
            scored_pairs.sort(key=lambda x: x['score'], reverse=True)
            
            return {"pairs": scored_pairs[:10]}  # Return top 10
            
        except Exception as e:
            print(f"Error fetching top pairs: {e}")
        
                        
            # Get ranked pairs from sophisticated pair manager
            if pair_manager:
                ranked_pairs = await pair_manager.rank_pairs()
            else:
                # Fallback to mock pairs if pair_manager not available
                raise Exception("PairManager not available")
            
            # Convert to API response format
            pairs_data = []
            for pair_score in ranked_pairs:
                pairs_data.append({
                    "symbol": pair_score.symbol,
                    "price": pair_score.price,
                    "volume24h": pair_score.volume_24h,
                    "change24h": pair_score.change_24h,
                    "score": round(pair_score.score, 1),
                    "regime": pair_score.regime,
                    "atr_pct": round(pair_score.atr_pct, 1),
                    "spread_bps": round(pair_score.spread_bps, 1),
                    "liquidity_score": round(pair_score.liquidity_score, 1),
                    "volatility_score": round(pair_score.volatility_score, 1),
                    "momentum_score": round(pair_score.momentum_score, 1),
                    "correlation_score": round(pair_score.correlation_score, 1),
                    "sentiment_score": round(pair_score.sentiment_score, 1),
                    "technical_score": round(pair_score.technical_score, 1)
                })
            
            return {"pairs": pairs_data}
            
        except Exception as e:
            print(f"Error fetching top pairs: {e}")
            raise HTTPException(status_code=503, detail=f"Failed to fetch market data: {str(e)}")

    @app.get("/config/trading-mode")
    def get_trading_mode():
        config = runtime.config.config.get("safety", {})
        return {
            "mode": config.get("START_MODE", "paper"),
            "live_enabled": config.get("LIVE_TRADING_ENABLED", False),
            "paper_balance": config.get("PAPER_EQUITY_START", 10000)
        }

    @app.post("/config/trading-mode")
    def set_trading_mode(request: dict):
        mode = request.get("mode", "paper")
        if mode not in ["paper", "live"]:
            raise HTTPException(status_code=400, detail="Mode must be 'paper' or 'live'")
        
        # Update config (in real implementation, save to config file)
        runtime.config.config["safety"]["START_MODE"] = mode
        runtime.config.config["safety"]["LIVE_TRADING_ENABLED"] = mode == "live"
        
        return {"mode": mode, "live_enabled": mode == "live"}

    @app.get("/config/telegram")
    def get_telegram_config():
        """Get telegram configuration from config.json."""
        # Access config through runtime.config which is a ConfigManager
        telegram_config = runtime.config.config.get("telegram", {})
        token = telegram_config.get("token", "")
        chat_id = str(telegram_config.get("chat_id", "")) if telegram_config.get("chat_id") else ""
        
        return {
            "bot_token": bool(token),
            "chat_id": bool(chat_id),
            "enabled": bool(token and chat_id),
            "token_preview": f"{token[:10]}..." if len(token) > 10 else token,
            "chat_id_value": chat_id
        }

    @app.post("/config/telegram")
    def set_telegram_config(request: dict):
        """Update telegram config (note: using existing config.json values)."""
        # Note: In production, you would update the config.json file
        # For now, return the existing config status
        return get_telegram_config()


    @app.get("/trading/status")
    def get_trading_status():
        """Get current trading status for all asset types."""
        try:
            config = runtime.config.config.get("bot_settings", {})
            enabled_products = config.get("products_enabled", [])
            
            status = {}
            asset_map = {
                "CRYPTO_SPOT": "crypto",
                "CRYPTO_FUTURES": "futures", 
                "FOREX_SPOT": "forex",
                "FOREX_OPTIONS": "forex_options"
            }
            
            for product in enabled_products:
                asset_type = asset_map.get(product, product.lower())
                status[asset_type] = {
                    "enabled": True,
                    "status": "active" if not runtime.get_state().get('global', {}).get('kill_switch', False) else "paused",
                    "mode": runtime.config.get("safety", {}).get("START_MODE", "paper")
                }
            
            return {"trading_status": status}
        except Exception as exc:
            return {"trading_status": {}}

    @app.get("/portfolio/positions")
    def get_positions():
        """Get current portfolio positions separated by paper/live."""
        try:
            # In real implementation, get from portfolio manager
            return {
                "paper_positions": [],
                "live_positions": [],
                "paper_balance": runtime.config.get("safety", {}).get("PAPER_EQUITY_START", 10000.0),
                "live_balance": 0.0
            }
        except Exception as exc:
            return {
                "paper_positions": [],
                "live_positions": [],
                "paper_balance": 10000.0,
                "live_balance": 0.0
            }

    @app.get("/bot/status")
    def get_bot_status():
        """Get detailed bot status including current activity."""
        try:
            state = runtime.get_state()
            config = runtime.config.config.get("safety", {})
            telegram_config = runtime.config.config.get("telegram", {})
            
            current_activity = "Idle"
            if not state.get('global', {}).get('kill_switch', False):
                if config.get("START_MODE", "paper") == "paper":
                    current_activity = "Paper Trading - Scanning for opportunities"
                else:
                    current_activity = "Live Trading - Monitoring positions"
            else:
                current_activity = "Paused - Kill switch active"
            
            return {
                "status": "online",
                "current_activity": current_activity,
                "trading_mode": config.get("START_MODE", "paper"),
                "kill_switch": state.get('global', {}).get('kill_switch', False),
                "telegram_configured": bool(telegram_config.get("token") and telegram_config.get("chat_id")),
                "last_update": "2025-08-25T18:25:30Z"
            }
        except Exception as exc:
            return {
                "status": "offline",
                "current_activity": "Service unavailable",
                "trading_mode": "unknown",
                "kill_switch": True,
                "telegram_configured": False,
                "last_update": "2025-08-25T18:25:30Z"
            }

    @app.get("/stats")
    def get_stats():
        """Get real trading statistics from runtime controller."""
        try:
            state = runtime.get_state()
            total_pnl = 0.0
            active_trades = 0
            win_rate = 0.0
            balance = 10000.0  # Default paper balance
            
            # Get actual stats from runtime if available
            if hasattr(runtime, 'get_portfolio_stats'):
                stats = runtime.get_portfolio_stats()
                total_pnl = stats.get('total_pnl', 0.0)
                active_trades = stats.get('active_trades', 0)
                win_rate = stats.get('win_rate', 0.0)
                balance = stats.get('balance', 10000.0)
            
            return {
                "total_pnl": total_pnl,
                "pnl_change": 0.0,  # Could calculate daily change
                "active_trades": active_trades,
                "trades_today": 0,  # Could track daily trades
                "win_rate": win_rate,
                "balance": balance
            }
        except Exception as exc:
            # Return safe defaults if stats unavailable
            return {
                "total_pnl": 0.0,
                "pnl_change": 0.0,
                "active_trades": 0,
                "trades_today": 0,
                "win_rate": 0.0,
                "balance": 10000.0
            }

    @app.get("/activity/recent")
    def get_recent_activity():
        """Get recent bot activity and status updates."""
        try:
            # Return the actual activity log
            activities = list(activity_log)
            
            # If no activities yet, add a default one
            if not activities:
                activities.append({
                    "type": "info",
                    "message": "Bot operational - monitoring markets",
                    "timestamp": datetime.now().isoformat(),
                    "source": "SYSTEM"
                })
            
            # Return in reverse order (newest first)
            activities.reverse()
            
            return {"activities": activities}
        except Exception as e:
            return {
                "activities": [
                    {"type": "error", "message": "Failed to load activity data", "timestamp": "2025-08-25T18:25:30Z"},
                    {"type": "info", "message": "Bot service may be starting up", "timestamp": "2025-08-25T18:25:30Z"}
                ]
            }

    @app.get("/stats/global")
    def get_global_stats():
        """Get global statistics across all assets."""
        try:
            state = runtime.get_state()
            
            # Initialize totals
            total_paper_balance = 0.0
            total_live_balance = 0.0
            paper_pnl = 0.0
            live_pnl = 0.0
            paper_session_pnl = 0.0
            live_session_pnl = 0.0
            active_assets = 0
            total_positions = 0
            
            # Aggregate data from all paper traders
            for asset in ['crypto', 'futures', 'forex', 'forex_options']:
                try:
                    if get_paper_trader:
                        paper_trader = get_paper_trader(asset)
                        if paper_trader:
                            # Get paper trading data
                            wallet_data = paper_trader.get_paper_wallet_data()
                            total_paper_balance += wallet_data['balance']
                            paper_pnl += wallet_data['pnl']
                            
                            # Count positions
                            total_positions += len([p for p in paper_trader.positions if p.get('status') == 'open'])
                            
                            # Check if asset is active
                            if hasattr(paper_trader, 'is_active') and paper_trader.is_active:
                                active_assets += 1
                except Exception as e:
                    print(f"Error getting {asset} paper trader data: {e}")
            
            # Get live balances if available (this would need real broker connections)
            # For now, using placeholder values
            
            return {
                "total_paper_balance": total_paper_balance,
                "total_live_balance": total_live_balance,
                "paper_pnl": paper_pnl,
                "live_pnl": live_pnl,
                "paper_session_pnl": paper_session_pnl,
                "live_session_pnl": live_session_pnl,
                "active_assets": f"{active_assets}/4",
                "total_positions": total_positions,
                "system_online": True
            }
        except Exception as exc:
            print(f"Error in global stats: {exc}")
            return {
                "total_paper_balance": 0.0,
                "total_live_balance": 0.0,
                "paper_pnl": 0.0,
                "live_pnl": 0.0,
                "paper_session_pnl": 0.0,
                "live_session_pnl": 0.0,
                "active_assets": "0/4",
                "total_positions": 0,
                "system_online": False
            }

    @app.get("/asset/{asset}/status")
    async def get_asset_status(asset: str):
        """Get status for a specific asset."""
        # Input validation
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        
        try:
            state = runtime.get_state()
            trading_state = state.get('trading', {}).get(asset.upper(), {})
            
            # Get paper wallet data from paper trader or config
            paper_balance = runtime.config.config.get('safety', {}).get('PAPER_EQUITY_START', 1000.0)
            if get_paper_trader:
                paper_trader = get_paper_trader(asset)
                # Initialize with config balance if not already set
                if not hasattr(paper_trader, 'balance') or paper_trader.balance <= 0:
                    paper_trader.balance = paper_balance
                    paper_trader.starting_balance = paper_balance
                    paper_trader.pnl_history = [{"timestamp": datetime.now().isoformat(), "balance": paper_balance}]
                paper_wallet_data = paper_trader.get_paper_wallet_data()
                
                # Calculate used in positions for paper trading
                used_in_positions = 0
                if hasattr(paper_trader, 'positions'):
                    for pos in paper_trader.positions:
                        if pos.get("status") == "open":
                            entry_price = pos.get("entry_price", 0)
                            size = pos.get("size", 0)
                            used_in_positions += entry_price * size
                
                paper_wallet_data["used_in_positions"] = used_in_positions
            else:
                # Fallback to config
                paper_wallet_data = {
                    "balance": paper_balance,
                    "pnl": 0.0,
                    "pnl_percent": 0.0,
                    "history": [{"balance": paper_balance}]
                }
            
            # Get live wallet data for crypto assets - ALWAYS try to show real balance
            live_wallet_data = {"balance": 0.0, "pnl": 0.0, "pnl_percent": 0.0, "history": [{"balance": 0.0}]}
            connection_status = "offline"
            
            # Always try to get live wallet balance for verification
            if asset == "crypto" and bybit_crypto:
                try:
                    # Try different account types based on Bybit V5 API documentation
                    account_types = ["UNIFIED", "CONTRACT", "SPOT"]
                    portfolio_state = None
                    
                    for account_type in account_types:
                        try:
                            print(f"Trying account type: {account_type}")
                            portfolio_state = await bybit_crypto.get_wallet_balance(account_type)
                            if portfolio_state and portfolio_state.total_balance_usd > 0:
                                print(f"Found balance with account type: {account_type}")
                                break
                        except Exception as e:
                            print(f"Account type {account_type} failed: {e}")
                            continue
                    
                    if portfolio_state:
                        connection_status = "connected"
                        live_wallet_data = {
                            "balance": portfolio_state.total_balance_usd,
                            "available_balance": portfolio_state.available_balance_usd,
                            "used_in_positions": portfolio_state.margin_used,
                            "pnl": portfolio_state.unrealized_pnl,
                            "pnl_percent": (portfolio_state.unrealized_pnl / portfolio_state.total_balance_usd * 100) if portfolio_state.total_balance_usd > 0 else 0.0,
                            "history": [{"balance": portfolio_state.total_balance_usd}]
                        }
                        print(f"Wallet data: {live_wallet_data}")
                        # Only log on first connection or balance change
                        # log_activity("BYBIT", f"{asset.upper()} wallet connected - Balance: ${portfolio_state.total_balance_usd:.2f}", "success")
                    else:
                        connection_status = "no_balance"
                        print("No balance found in any account type")
                        
                except Exception as e:
                    print(f"Failed to get Bybit wallet data: {e}")
                    connection_status = "offline"
            elif asset == "futures" and bybit_futures:
                try:
                    # Try different account types for futures (UNIFIED first as it's most common in V5)
                    account_types = ["UNIFIED", "CONTRACT"]
                    portfolio_state = None
                    
                    for account_type in account_types:
                        try:
                            print(f"Trying futures account type: {account_type}")
                            portfolio_state = await bybit_futures.get_wallet_balance(account_type)
                            if portfolio_state and portfolio_state.total_balance_usd > 0:
                                print(f"Found futures balance with account type: {account_type}")
                                break
                        except Exception as e:
                            print(f"Futures account type {account_type} failed: {e}")
                            continue
                    
                    if portfolio_state:
                        connection_status = "connected"
                        live_wallet_data = {
                            "balance": portfolio_state.total_balance_usd,
                            "available_balance": portfolio_state.available_balance_usd,
                            "used_in_positions": portfolio_state.margin_used,
                            "pnl": portfolio_state.unrealized_pnl,
                            "pnl_percent": (portfolio_state.unrealized_pnl / portfolio_state.total_balance_usd * 100) if portfolio_state.total_balance_usd > 0 else 0.0,
                            "history": [{"balance": portfolio_state.total_balance_usd}]
                        }
                    else:
                        connection_status = "no_balance"
                        
                except Exception as e:
                    print(f"Failed to get Bybit futures data: {e}")
                    connection_status = "offline"
            elif asset in ["forex", "forex_options"] and ibkr_connection_manager:
                try:
                    # Get IBKR account balance
                    if ibkr_connection_manager.is_connected():
                        connection_status = "connected"
                        live_wallet_data = await ibkr_connection_manager.get_wallet_data()
                        # Only log on first connection or balance change
                        # log_activity("IBKR", f"{asset.upper()} wallet connected - Balance: ${live_wallet_data['balance']:.2f}")
                    else:
                        connection_status = "offline"
                        print("IBKR not connected")
                except Exception as e:
                    print(f"Failed to get IBKR wallet data: {e}")
                    connection_status = "offline"
            
            return {
                "connection_status": connection_status,
                "paper_trading_active": trading_state.get('status') == 'running' and trading_state.get('mode') == 'paper',
                "live_trading_active": trading_state.get('status') == 'running' and trading_state.get('mode') == 'live',
                "live_trading_approved": connection_status == "connected",  # Approve if connected
                "kill_switch_active": state.get('global', {}).get('kill_switch', False),
                "paper_wallet": paper_wallet_data,
                "live_wallet": live_wallet_data
            }
        except Exception as exc:
            # Return safe defaults if data unavailable
            return {
                "connection_status": "offline",
                "paper_trading_active": False,
                "live_trading_active": False,
                "live_trading_approved": False,
                "kill_switch_active": True,
                "paper_wallet": {"balance": 0.0, "pnl": 0.0, "pnl_percent": 0.0, "history": []},
                "live_wallet": {"balance": 0.0, "pnl": 0.0, "pnl_percent": 0.0, "history": []}
            }

    @app.get("/asset/{asset}/positions")
    def get_asset_positions(asset: str):
        """Get current positions for a specific asset (separated by paper/live)."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        
        try:
            # Paper trading positions
            paper_positions = []
            paper_daily_pnl = 0.0
            
            if get_paper_trader:
                paper_trader = get_paper_trader(asset)
                paper_positions = paper_trader.get_positions()
                paper_daily_pnl = sum(p.get('pnl', 0) for p in paper_positions)
            
            # Live trading positions (placeholder - implement when live trading is ready)
            live_positions = []
            live_daily_pnl = 0.0
            
            return {
                "paper": {
                    "positions": paper_positions,
                    "daily_pnl": paper_daily_pnl,
                    "position_count": len(paper_positions)
                },
                "live": {
                    "positions": live_positions,
                    "daily_pnl": live_daily_pnl,
                    "position_count": len(live_positions)
                }
            }
        except Exception as exc:
            return {
                "paper": {
                    "positions": [],
                    "daily_pnl": 0.0,
                    "position_count": 0
                },
                "live": {
                    "positions": [],
                    "daily_pnl": 0.0,
                    "position_count": 0
                }
            }

    @app.get("/asset/{asset}/strategies")
    def get_asset_strategies_summary(asset: str):
        """Get strategy development status for a specific asset."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        
        try:
            # Get strategy development information
            if strategy_manager:
                strategy_data = strategy_manager.get_strategies_by_asset(asset)
                summary = strategy_data['summary']
                
                return {
                    "paper_trading": {
                        "developing_strategies": summary['developing'],
                        "pending_validation": summary['pending_validation'], 
                        "total_developed": summary['total']
                    },
                    "live_trading": {
                        "approved_strategies": summary['live'],
                        "validated_ready": summary['validated'],
                        "rejected": summary['rejected']
                    },
                    "development_pipeline": {
                        "developing": summary['developing'],
                        "validation_pending": summary['pending_validation'],
                        "validation_ready": summary['validated'],
                        "live_approved": summary['live']
                    }
                }
            else:
                # Fallback without strategy manager
                return {
                    "paper_trading": {
                        "developing_strategies": 0,
                        "pending_validation": 0,
                        "total_developed": 0
                    },
                    "live_trading": {
                        "approved_strategies": 0,
                        "validated_ready": 0,
                        "rejected": 0
                    },
                    "development_pipeline": {
                        "developing": 0,
                        "validation_pending": 0,
                        "validation_ready": 0,
                        "live_approved": 0
                    }
                }
        except Exception as exc:
            return {
                "paper_trading": {
                    "developing_strategies": 0,
                    "pending_validation": 0,
                    "total_developed": 0
                },
                "live_trading": {
                    "approved_strategies": 0,
                    "validated_ready": 0,
                    "rejected": 0
                },
                "development_pipeline": {
                    "developing": 0,
                    "validation_pending": 0,
                    "validation_ready": 0,
                    "live_approved": 0
                }
            }

    @app.post("/asset/{asset}/kill")
    def kill_asset_trading(asset: str):
        """Activate kill switch for specific asset."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        
        try:
            runtime.kill_asset_trading(asset.upper())
            return {
                "asset": asset,
                "status": "killed"
            }
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to kill {asset} trading: {exc}")

    @app.post("/emergency/stop")
    def emergency_stop_all():
        """Emergency stop all trading across all assets."""
        try:
            runtime.emergency_stop_all()
            return {
                "status": "emergency_stop_activated",
                "message": "All trading stopped across all assets"
            }
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to activate emergency stop: {exc}")

    @app.get("/brokers/status")
    async def get_broker_status():
        """Get status of broker connections."""
        try:
            # Check actual broker connections
            bybit_status = "offline"
            if bybit_crypto or bybit_futures:
                try:
                    # Test connection using the new connection test method
                    if bybit_crypto:
                        connection_ok = await bybit_crypto.test_connection()
                        if connection_ok:
                            bybit_status = "connected"
                        else:
                            bybit_status = "auth_failed"
                    elif bybit_futures:
                        connection_ok = await bybit_futures.test_connection()
                        if connection_ok:
                            bybit_status = "connected"
                        else:
                            bybit_status = "auth_failed"
                except Exception as e:
                    print(f"Bybit connection test failed: {e}")
                    bybit_status = "offline"
            
            # Check IBKR connection
            ibkr_status = "offline"
            if ibkr_connection_manager:
                try:
                    if ibkr_connection_manager.ib.isConnected():
                        ibkr_status = "connected"
                    # Don't auto-connect in status check - let user do it manually
                except Exception as e:
                    print(f"IBKR connection check failed: {e}")
                    ibkr_status = "offline"
            
            return {
                "bybit_status": bybit_status,
                "ibkr_status": ibkr_status,
                "bybit_error": "Check API credentials" if bybit_status == "auth_failed" else None
            }
        except Exception as exc:
            return {
                "bybit_status": "offline",
                "ibkr_status": "offline",
                "error": str(exc)
            }

    @app.get("/ping")
    def ping():
        """Simple ping endpoint to test if server is responding."""
        return {"status": "ok", "message": "Server is responding", "timestamp": datetime.now().isoformat()}
    
    @app.get("/price/{symbol}")
    async def get_price(symbol: str):
        """Get real-time price for a symbol."""
        try:
            # Check if it's a crypto symbol (ends with USDT or is a common crypto pair)
            crypto_symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT", 
                            "ADAUSDT", "DOGEUSDT", "MATICUSDT", "DOTUSDT", "AVAXUSDT"]
            
            if symbol in crypto_symbols or symbol.endswith("USDT"):
                if not bybit_crypto:
                    raise HTTPException(status_code=503, detail="Bybit connection not available")
                
                # Get ticker data from Bybit
                ticker_response = await bybit_crypto.client.get_tickers(
                    category="spot",
                    symbol=symbol
                )
                
                if ticker_response and ticker_response.get('retCode') == 0:
                    tickers = ticker_response.get('result', {}).get('list', [])
                    if tickers:
                        ticker = tickers[0]
                        return {
                            "symbol": symbol,
                            "price": float(ticker.get('lastPrice', 0)),
                            "change_24h": float(ticker.get('price24hPcnt', 0)) * 100,
                            "volume_24h": float(ticker.get('volume24h', 0)) * float(ticker.get('lastPrice', 0)),
                            "bid": float(ticker.get('bid1Price', 0)),
                            "ask": float(ticker.get('ask1Price', 0)),
                            "high_24h": float(ticker.get('highPrice24h', 0)),
                            "low_24h": float(ticker.get('lowPrice24h', 0)),
                            "timestamp": datetime.now().isoformat()
                        }
                
            # Forex symbols
            elif symbol in ["EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "NZDUSD", "USDCAD"]:
                if ibkr_connection_manager and ibkr_connection_manager.ib.isConnected():
                    from ib_insync import Forex
                    contract = Forex(symbol[:3] + symbol[3:])
                    ticker = ibkr_connection_manager.ib.reqMktData(contract)
                    ibkr_connection_manager.ib.sleep(1)  # Wait for data
                    
                    if ticker.marketPrice() > 0:
                        return {
                            "symbol": symbol,
                            "price": ticker.marketPrice(),
                            "bid": ticker.bid if ticker.bid > 0 else ticker.marketPrice(),
                            "ask": ticker.ask if ticker.ask > 0 else ticker.marketPrice(),
                            "timestamp": datetime.now().isoformat()
                        }
            
            # SPX for options
            elif symbol == "SPX":
                if ibkr_connection_manager and ibkr_connection_manager.ib.isConnected():
                    from ib_insync import Index
                    contract = Index('SPX', 'CBOE')
                    ticker = ibkr_connection_manager.ib.reqMktData(contract)
                    ibkr_connection_manager.ib.sleep(1)
                    
                    if ticker.marketPrice() > 0:
                        return {
                            "symbol": symbol,
                            "price": ticker.marketPrice(),
                            "bid": ticker.bid if ticker.bid > 0 else ticker.marketPrice(),
                            "ask": ticker.ask if ticker.ask > 0 else ticker.marketPrice(),
                            "timestamp": datetime.now().isoformat()
                        }
            
            # If we reach here, we couldn't fetch the price
            raise HTTPException(status_code=404, detail=f"Price data not available for {symbol}")
            
        except Exception as e:
            print(f"Error fetching price for {symbol}: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to fetch price: {str(e)}")
    
    @app.post("/ibkr/connect")
    async def connect_ibkr():
        """Manually trigger IBKR connection."""
        if not ibkr_connection_manager:
            raise HTTPException(status_code=500, detail="IBKR connection manager not initialized")
        
        try:
            await ibkr_connection_manager.connect_tws()
            return {
                "status": "connected",
                "message": "Successfully connected to TWS",
                "account": ibkr_connection_manager.ib.managedAccounts()[0] if ibkr_connection_manager.ib.managedAccounts() else None,
                "is_paper": ibkr_connection_manager._is_paper_account
            }
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to connect to TWS: {str(e)}")
    
    @app.get("/debug/bybit")
    def debug_bybit_connection():
        """Debug Bybit connection and show detailed error information."""
        try:
            import asyncio
            debug_info = {
                "config_loaded": False,
                "api_credentials": False,
                "connection_test": False,
                "wallet_balance_test": False,
                "account_types_tested": [],
                "errors": []
            }
            
            # Check config
            try:
                api_keys = runtime.config.config.get("api_keys", {}).get("bybit", {})
                api_key = api_keys.get("key")
                api_secret = api_keys.get("secret")
                
                debug_info["config_loaded"] = True
                debug_info["api_credentials"] = bool(api_key and api_secret)
                debug_info["api_key_preview"] = f"{api_key[:10]}..." if api_key else "Not found"
                
            except Exception as e:
                debug_info["errors"].append(f"Config error: {str(e)}")
            
            # Test connection if we have credentials
            if debug_info["api_credentials"] and bybit_crypto:
                try:
                    connection_test = asyncio.run(bybit_crypto.test_connection())
                    debug_info["connection_test"] = connection_test
                    if not connection_test:
                        debug_info["errors"].append("Connection test failed - check API credentials")
                except Exception as e:
                    debug_info["errors"].append(f"Connection test error: {str(e)}")
                
                # Test wallet balance with different account types
                if debug_info["connection_test"]:
                    account_types = ["UNIFIED", "CONTRACT", "SPOT"]
                    for account_type in account_types:
                        try:
                            result = asyncio.run(bybit_crypto.get_wallet_balance(account_type))
                            test_result = {
                                "account_type": account_type,
                                "success": result is not None,
                                "balance": result.total_balance_usd if result else 0,
                                "available": result.available_balance_usd if result else 0
                            }
                            debug_info["account_types_tested"].append(test_result)
                            if result and result.total_balance_usd > 0:
                                debug_info["wallet_balance_test"] = True
                        except Exception as e:
                            debug_info["account_types_tested"].append({
                                "account_type": account_type,
                                "success": False,
                                "error": str(e)
                            })
            
            return debug_info
            
        except Exception as exc:
            return {
                "error": f"Debug failed: {str(exc)}",
                "suggestion": "Check server logs for more details"
            }
    
    # ===== COMPREHENSIVE TRADING ANALYTICS ENDPOINTS =====
    
    @app.get("/analytics/{asset}/{mode}/reward-summary")
    def get_reward_summary(asset: str, mode: str):
        """Get comprehensive reward and performance summary."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        valid_modes = ['paper', 'live']
        
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        if mode not in valid_modes:
            raise HTTPException(status_code=400, detail=f"Invalid mode. Must be one of: {valid_modes}")
            
        try:
            if mode == "paper" and get_paper_trader:
                paper_trader = get_paper_trader(asset)
                stats = paper_trader.get_trading_stats()
                wallet_data = paper_trader.get_paper_wallet_data()
                
                # Calculate reward system metrics
                closed_trades = [t for t in paper_trader.trades if t.get('status') == 'closed']
                total_reward_points = sum(t.get('reward_points', 0) for t in closed_trades)
                avg_reward_per_trade = total_reward_points / len(closed_trades) if closed_trades else 0
                
                # Calculate consecutive stop loss hits
                consecutive_sl_count = 0
                for trade in reversed(closed_trades[-10:]):  # Check last 10 trades
                    if trade.get('exit_reason') == 'Stop Loss Hit':
                        consecutive_sl_count += 1
                    else:
                        break
                
                # Create reward summary from available data
                return {
                    "mode": "PAPER",
                    "asset_type": asset.upper(),
                    "overall_performance": {
                        "total_return_pct": stats.get('total_return', 0),
                        "net_pnl": stats.get('net_pnl', 0),
                        "current_balance": wallet_data.get('balance', 0),
                        "starting_balance": stats.get('starting_balance', 0)
                    },
                    "trading_metrics": {
                        "total_trades": stats.get('total_trades', 0),
                        "win_rate": stats.get('win_rate', 0),
                        "profit_factor": stats.get('profit_factor', 0),
                        "avg_win": stats.get('avg_win', 0),
                        "avg_loss": stats.get('avg_loss', 0),
                        "max_win": stats.get('max_win', 0),
                        "max_loss": stats.get('max_loss', 0)
                    },
                    "fees_and_costs": {
                        "total_penalties": stats.get('total_penalties', 0),
                        "violation_count": stats.get('violation_count', 0)
                    },
                    "reward_system_metrics": {
                        "total_reward_points": total_reward_points,
                        "avg_reward_per_trade": avg_reward_per_trade,
                        "consecutive_sl_hits": consecutive_sl_count
                    },
                    "recent_performance": wallet_data.get('history', [])[-10:]
                }
            elif mode == "live":
                # TODO: Implement live trading analytics
                return {
                    "mode": "LIVE",
                    "asset_type": asset.upper(),
                    "message": "Live trading analytics not yet implemented",
                    "overall_performance": {},
                    "trading_metrics": {},
                    "fees_and_costs": {},
                    "symbol_breakdown": {},
                    "recent_trades": []
                }
            else:
                raise HTTPException(status_code=404, detail="Paper trader not available")
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to get reward summary: {exc}")
    
    @app.get("/analytics/{asset}/{mode}/detailed-trades")
    def get_detailed_trades(asset: str, mode: str, limit: int = 50):
        """Get detailed trade history with all information."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        valid_modes = ['paper', 'live']
        
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        if mode not in valid_modes:
            raise HTTPException(status_code=400, detail=f"Invalid mode. Must be one of: {valid_modes}")
        if limit > 500:  # Prevent excessive data requests
            limit = 500
            
        try:
            if mode == "paper" and get_paper_trader:
                paper_trader = get_paper_trader(asset)
                trades = paper_trader.get_detailed_trades(limit)
                return {
                    "trades": trades,
                    "total_count": len(paper_trader.trades),
                    "displayed_count": len(trades),
                    "asset": asset.upper(),
                    "mode": mode.upper()
                }
            elif mode == "live":
                # TODO: Implement live trading detailed trades
                return {
                    "trades": [],
                    "total_count": 0,
                    "displayed_count": 0,
                    "asset": asset.upper(),
                    "mode": mode.upper(),
                    "message": "Live trading trade history not yet implemented"
                }
            else:
                raise HTTPException(status_code=404, detail="Paper trader not available")
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to get detailed trades: {exc}")
    
    @app.get("/analytics/{asset}/{mode}/symbol-performance")
    def get_symbol_performance(asset: str, mode: str):
        """Get performance breakdown by cryptocurrency symbols."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        valid_modes = ['paper', 'live']
        
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        if mode not in valid_modes:
            raise HTTPException(status_code=400, detail=f"Invalid mode. Must be one of: {valid_modes}")
            
        try:
            if mode == "paper" and get_paper_trader:
                paper_trader = get_paper_trader(asset)
                symbol_stats = paper_trader.get_performance_by_symbol()
                return {
                    "symbol_performance": symbol_stats,
                    "asset": asset.upper(),
                    "mode": mode.upper(),
                    "total_symbols": len(symbol_stats)
                }
            elif mode == "live":
                # TODO: Implement live trading symbol performance
                return {
                    "symbol_performance": {},
                    "asset": asset.upper(),
                    "mode": mode.upper(),
                    "total_symbols": 0,
                    "message": "Live trading symbol performance not yet implemented"
                }
            else:
                raise HTTPException(status_code=404, detail="Paper trader not available")
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to get symbol performance: {exc}")
    
    @app.get("/analytics/{asset}/{mode}/trading-stats")
    def get_enhanced_trading_stats(asset: str, mode: str):
        """Get comprehensive trading statistics."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        valid_modes = ['paper', 'live']
        
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        if mode not in valid_modes:
            raise HTTPException(status_code=400, detail=f"Invalid mode. Must be one of: {valid_modes}")
            
        try:
            if mode == "paper" and get_paper_trader:
                paper_trader = get_paper_trader(asset)
                stats = paper_trader.get_trading_stats()
                return {
                    "statistics": stats,
                    "asset": asset.upper(),
                    "mode": mode.upper(),
                    "last_updated": datetime.now().isoformat()
                }
            elif mode == "live":
                # TODO: Implement live trading statistics
                return {
                    "statistics": {},
                    "asset": asset.upper(),
                    "mode": mode.upper(),
                    "message": "Live trading statistics not yet implemented"
                }
            else:
                raise HTTPException(status_code=404, detail="Paper trader not available")
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to get trading stats: {exc}")
    
    @app.get("/analytics/overview")
    def get_analytics_overview():
        """Get overview of analytics across all assets and modes."""
        try:
            overview = {
                "paper_trading": {},
                "live_trading": {},
                "total_performance": {
                    "total_paper_pnl": 0,
                    "total_live_pnl": 0,
                    "total_trades": 0,
                    "best_performing_asset": "",
                    "worst_performing_asset": ""
                }
            }
            
            assets = ['crypto', 'futures', 'forex', 'forex_options']
            best_performance = -float('inf')
            worst_performance = float('inf')
            
            # Collect paper trading data
            for asset in assets:
                if get_paper_trader:
                    try:
                        paper_trader = get_paper_trader(asset)
                        stats = paper_trader.get_trading_stats()
                        
                        overview["paper_trading"][asset] = {
                            "balance": stats.get('current_balance', 0),
                            "total_return_pct": stats.get('total_return', 0),
                            "total_trades": stats.get('total_trades', 0),
                            "win_rate": stats.get('win_rate', 0),
                            "total_pnl": stats.get('total_pnl', 0)
                        }
                        
                        # Track best/worst performing
                        total_return = stats.get('total_return', 0)
                        if total_return > best_performance:
                            best_performance = total_return
                            overview["total_performance"]["best_performing_asset"] = f"{asset} (paper)"
                        if total_return < worst_performance:
                            worst_performance = total_return
                            overview["total_performance"]["worst_performing_asset"] = f"{asset} (paper)"
                        
                        # Add to totals
                        overview["total_performance"]["total_paper_pnl"] += stats.get('total_pnl', 0)
                        overview["total_performance"]["total_trades"] += stats.get('total_trades', 0)
                        
                    except Exception as e:
                        overview["paper_trading"][asset] = {"error": str(e)}
            
            # TODO: Add live trading data collection when implemented
            for asset in assets:
                overview["live_trading"][asset] = {
                    "status": "not_implemented",
                    "message": "Live trading analytics coming soon"
                }
            
            return overview
            
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to get analytics overview: {exc}")
    
    @app.get("/rewards/{asset}/recent")
    def get_recent_rewards(asset: str):
        """Get recent reward notifications for an asset."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        
        try:
            if get_paper_trader:
                paper_trader = get_paper_trader(asset)
                recent_rewards = paper_trader.get_recent_rewards()
                return {
                    "asset": asset,
                    "recent_rewards": recent_rewards,
                    "count": len(recent_rewards),
                    "last_updated": datetime.now().isoformat()
                }
            else:
                return {
                    "asset": asset,
                    "recent_rewards": [],
                    "count": 0,
                    "message": "Paper trader not available"
                }
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to get recent rewards: {exc}")
    
    # ===== STRATEGY DEVELOPMENT ENDPOINTS =====
    
    @app.get("/strategies/summary")
    def get_strategy_summary():
        """Get overall strategy development summary."""
        if not strategy_manager:
            return {
                "error": "Strategy development manager not available",
                "total_strategies": 0,
                "by_status": {},
                "by_asset": {}
            }
        
        try:
            return strategy_manager.get_strategy_summary()
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to get strategy summary: {exc}")
    
    @app.get("/strategies/{asset}")
    def get_asset_strategies(asset: str):
        """Get strategies for a specific asset."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        
        if not strategy_manager:
            return {
                "asset_type": asset,
                "strategies": {},
                "summary": {
                    "total": 0,
                    "developing": 0,
                    "pending_validation": 0,
                    "validated": 0,
                    "live": 0,
                    "rejected": 0
                }
            }
        
        try:
            return strategy_manager.get_strategies_by_asset(asset)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to get strategies for {asset}: {exc}")
    
    @app.post("/strategies/{strategy_id}/validate")
    async def validate_strategy(strategy_id: str):
        """Trigger validation for a strategy."""
        if not strategy_manager:
            raise HTTPException(status_code=503, detail="Strategy development manager not available")
        
        try:
            passed, reasons = await strategy_manager.validate_strategy(strategy_id)
            return {
                "strategy_id": strategy_id,
                "validation_passed": passed,
                "reasons": reasons,
                "timestamp": datetime.now().isoformat()
            }
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to validate strategy {strategy_id}: {exc}")
    
    @app.post("/strategies/{strategy_id}/approve-live")
    def approve_strategy_for_live(strategy_id: str):
        """Approve a validated strategy for live testing."""
        if not strategy_manager:
            raise HTTPException(status_code=503, detail="Strategy development manager not available")
        
        try:
            success = strategy_manager.approve_for_live_testing(strategy_id)
            if success:
                return {
                    "strategy_id": strategy_id,
                    "approved": True,
                    "message": "Strategy approved for live testing",
                    "timestamp": datetime.now().isoformat()
                }
            else:
                raise HTTPException(status_code=400, detail="Strategy not eligible for live approval")
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to approve strategy {strategy_id}: {exc}")

    @app.post("/asset/{asset}/clear-history")
    def clear_paper_trading_history(asset: str):
        """Clear all paper trading history and reset to starting balance."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        
        try:
            if get_paper_trader:
                paper_trader = get_paper_trader(asset)
                
                # Get initial balance from config
                starting_balance = runtime.config.config.get('safety', {}).get('PAPER_EQUITY_START', 1000.0)
                
                # Reset paper trader state
                paper_trader.balance = starting_balance
                paper_trader.starting_balance = starting_balance
                paper_trader.positions = []
                paper_trader.trades = []
                paper_trader.pnl_history = [{
                    "timestamp": datetime.now().isoformat(), 
                    "balance": starting_balance
                }]
                paper_trader.violations_log = []
                paper_trader.violation_count = 0
                
                # Save the reset state
                paper_trader._save_state()
                
                return {
                    "asset": asset,
                    "status": "cleared",
                    "message": f"Paper trading history cleared for {asset}",
                    "new_balance": starting_balance,
                    "timestamp": datetime.now().isoformat()
                }
            else:
                raise HTTPException(status_code=503, detail="Paper trader not available")
                
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to clear {asset} paper trading history: {exc}")

    # ===== ROLLOUT CONTROL ENDPOINTS =====
    
    @app.get("/rollout/status")
    def get_rollout_status():
        """Get rollout status for all assets and modes."""
        try:
            rollout_status = {}
            
            for asset in ['crypto', 'futures', 'forex', 'forex_options']:
                asset_status = runtime.get_state().get('trading', {}).get(asset.upper(), {})
                
                # Check paper trading status
                paper_blockers = []
                if runtime.get_state().get('global', {}).get('kill_switch', False):
                    paper_blockers.append({"type": "kill-switch", "reason": "Global kill switch active"})
                
                # Check live trading status and blockers
                live_blockers = []
                if runtime.get_state().get('global', {}).get('kill_switch', False):
                    live_blockers.append({"type": "kill-switch", "reason": "Global kill switch active"})
                
                # Check broker connection
                if asset in ['crypto', 'futures']:
                    if not bybit_crypto and not bybit_futures:
                        live_blockers.append({"type": "broker-desync", "reason": "Bybit not connected"})
                else:
                    live_blockers.append({"type": "broker-desync", "reason": "IBKR not connected"})
                
                # Check for approved strategies
                if strategy_manager:
                    strategies = strategy_manager.get_strategies_by_asset(asset)
                    if strategies['summary']['live'] == 0:
                        live_blockers.append({"type": "validation-pending", "reason": "No approved live strategies"})
                
                # Check budget/allocation
                # TODO: Implement budget checking
                
                rollout_status[asset] = {
                    "paper": {
                        "enabled": asset_status.get('paper_enabled', False),
                        "blockers": paper_blockers
                    },
                    "live": {
                        "enabled": asset_status.get('live_enabled', False),
                        "blockers": live_blockers
                    }
                }
            
            return rollout_status
            
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to get rollout status: {exc}")
    
    @app.post("/rollout/{asset}/{mode}/enable")
    def enable_rollout(asset: str, mode: str):
        """Enable trading for specific asset and mode."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        valid_modes = ['paper', 'live']
        
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        if mode not in valid_modes:
            raise HTTPException(status_code=400, detail=f"Invalid mode. Must be one of: {valid_modes}")
        
        try:
            # Get current status
            status = runtime.get_state()
            
            # Check blockers
            if mode == 'live':
                # Verify broker connection
                if asset in ['crypto', 'futures'] and not (bybit_crypto or bybit_futures):
                    return {"ok": False, "reason": "Broker not connected", "enabled": False}
                
                # Verify approved strategies
                if strategy_manager:
                    strategies = strategy_manager.get_strategies_by_asset(asset)
                    if strategies['summary']['live'] == 0:
                        return {"ok": False, "reason": "No approved live strategies", "enabled": False}
            
            # Enable the mode
            runtime.enable_trading(asset.upper(), mode)
            
            # Log the action
            print(f"[ROLLOUT] {asset.upper()} {mode} trading enabled by user")
            
            return {"ok": True, "enabled": True}
            
        except Exception as exc:
            return {"ok": False, "reason": str(exc), "enabled": False}
    
    @app.post("/rollout/{asset}/{mode}/disable")
    def disable_rollout(asset: str, mode: str):
        """Disable trading for specific asset and mode."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        valid_modes = ['paper', 'live']
        
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        if mode not in valid_modes:
            raise HTTPException(status_code=400, detail=f"Invalid mode. Must be one of: {valid_modes}")
        
        try:
            # Disable the mode
            runtime.disable_trading(asset.upper(), mode)
            
            # Log the action
            print(f"[ROLLOUT] {asset.upper()} {mode} trading disabled by user")
            
            return {"ok": True, "enabled": False}
            
        except Exception as exc:
            return {"ok": False, "reason": str(exc), "enabled": False}
    
    # ===== SAFE RESET ENDPOINTS =====
    
    @app.get("/maintenance/preview")
    def preview_maintenance_action(asset: str, type: str):
        """Preview what will be affected by a maintenance action."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        valid_types = ['paper', 'model']
        
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        if type not in valid_types:
            raise HTTPException(status_code=400, detail=f"Invalid type. Must be one of: {valid_types}")
        
        try:
            if type == 'paper':
                # Get paper trading data counts
                if get_paper_trader:
                    paper_trader = get_paper_trader(asset)
                    return {
                        "trade_count": len(paper_trader.trades),
                        "position_count": len(paper_trader.positions),
                        "epoch_count": len(getattr(paper_trader, 'epochs', [])),
                        "metrics_size": 1024 * len(paper_trader.trades),  # Estimate
                        "total_size": 2048 * len(paper_trader.trades)  # Estimate
                    }
                else:
                    return {
                        "trade_count": 0,
                        "position_count": 0,
                        "epoch_count": 0,
                        "metrics_size": 0,
                        "total_size": 0
                    }
            else:  # model
                # Get model data estimates
                return {
                    "checkpoint_count": 3,  # Placeholder
                    "buffer_count": 2,
                    "feature_size": 1024 * 1024 * 10,  # 10MB estimate
                    "log_size": 1024 * 512,  # 512KB estimate
                    "total_size": 1024 * 1024 * 15  # 15MB total
                }
                
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to preview maintenance action: {exc}")
    
    @app.post("/maintenance/paper_reset")
    def reset_paper_history(request: dict):
        """Reset paper trading history with safety checks."""
        asset = request.get("asset")
        dry_run = request.get("dry_run", True)
        backup = request.get("backup", True)
        reason = request.get("reason", "Manual reset")
        quarantine = request.get("quarantine", False)
        
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options', 'spot', 'futures', 'forex', 'options']
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        
        try:
            # Normalize asset names
            asset_map = {
                'spot': 'crypto',
                'options': 'forex_options'
            }
            normalized_asset = asset_map.get(asset, asset)
            
            if get_paper_trader:
                paper_trader = get_paper_trader(normalized_asset)
                
                # Count items to be deleted
                deleted_count = len(paper_trader.trades) + len(paper_trader.positions)
                
                if dry_run:
                    return {
                        "dry_run": True,
                        "affected_count": deleted_count,
                        "backup_location": f"/backups/{datetime.now().strftime('%Y%m%d_%H%M%S')}/{normalized_asset}/" if backup else None
                    }
                
                # Perform backup if requested
                if backup:
                    import json
                    import os
                    backup_dir = f"./backups/{datetime.now().strftime('%Y%m%d_%H%M%S')}/{normalized_asset}/"
                    os.makedirs(backup_dir, exist_ok=True)
                    
                    # Save current state
                    with open(f"{backup_dir}/trades.json", 'w') as f:
                        json.dump(paper_trader.trades, f, indent=2)
                    with open(f"{backup_dir}/positions.json", 'w') as f:
                        json.dump(paper_trader.positions, f, indent=2)
                    with open(f"{backup_dir}/state.json", 'w') as f:
                        json.dump({
                            "balance": paper_trader.balance,
                            "starting_balance": paper_trader.starting_balance,
                            "pnl_history": paper_trader.pnl_history
                        }, f, indent=2)
                
                # Quarantine corrupted samples if requested
                if quarantine and len(paper_trader.trades) > 0:
                    # Move suspicious trades to quarantine
                    # TODO: Implement corruption detection logic
                    pass
                
                # Pause trading during reset
                runtime.pause_asset_trading(normalized_asset.upper())
                
                # Perform reset
                starting_balance = runtime.config.config.get('safety', {}).get('PAPER_EQUITY_START', 1000.0)
                paper_trader.balance = starting_balance
                paper_trader.starting_balance = starting_balance
                paper_trader.positions = []
                paper_trader.trades = []
                paper_trader.pnl_history = [{
                    "timestamp": datetime.now().isoformat(), 
                    "balance": starting_balance
                }]
                paper_trader.violations_log = []
                paper_trader.violation_count = 0
                
                # Save state
                paper_trader._save_state()
                
                # Resume trading
                runtime.resume_asset_trading(normalized_asset.upper())
                
                # Log the action
                print(f"[MAINTENANCE] Paper history reset for {normalized_asset}: {deleted_count} items deleted. Reason: {reason}")
                
                return {
                    "success": True,
                    "deleted_count": deleted_count,
                    "backup_location": f"./backups/{datetime.now().strftime('%Y%m%d_%H%M%S')}/{normalized_asset}/" if backup else None,
                    "timestamp": datetime.now().isoformat()
                }
                
            else:
                raise HTTPException(status_code=503, detail="Paper trader not available")
                
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to reset paper history: {exc}")
    
    @app.post("/maintenance/model_reset")
    def reset_training_model(request: dict):
        """Reset training model with safety checks."""
        asset = request.get("asset")
        dry_run = request.get("dry_run", True)
        backup = request.get("backup", True)
        reason = request.get("reason", "Manual reset")
        wipe_feature_store = request.get("wipe_feature_store", True)
        
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options', 'spot', 'futures', 'forex', 'options']
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        
        try:
            # Normalize asset names
            asset_map = {
                'spot': 'crypto',
                'options': 'forex_options'
            }
            normalized_asset = asset_map.get(asset, asset)
            
            # Estimate model files (placeholder implementation)
            model_file_count = 5  # Checkpoints, buffers, etc.
            
            if dry_run:
                return {
                    "dry_run": True,
                    "affected_count": model_file_count,
                    "backup_location": f"/backups/{datetime.now().strftime('%Y%m%d_%H%M%S')}/{normalized_asset}/models/" if backup else None
                }
            
            # TODO: Implement actual model reset logic
            # This would involve:
            # 1. Backing up model files if requested
            # 2. Pausing training/inference
            # 3. Deleting checkpoints and buffers
            # 4. Wiping feature store if requested
            # 5. Resuming with fresh model
            
            # Log the action
            print(f"[MAINTENANCE] Model reset for {normalized_asset}. Reason: {reason}")
            
            return {
                "success": True,
                "deleted_count": model_file_count,
                "backup_location": f"./backups/{datetime.now().strftime('%Y%m%d_%H%M%S')}/{normalized_asset}/models/" if backup else None,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to reset model: {exc}")

    @app.post("/shutdown")
    async def shutdown_server():
        """Shutdown the server gracefully."""
        import os
        import signal
        import threading
        
        def shutdown():
            # Give time for response to be sent
            import time
            time.sleep(1)
            # Send shutdown signal
            os.kill(os.getpid(), signal.SIGTERM)
        
        # Run shutdown in background thread
        threading.Thread(target=shutdown).start()
        
        return {"status": "shutting down", "message": "Server is shutting down..."}
    
    @app.post("/asset/{asset}/start/{mode}")
    async def start_asset_trading_endpoint(asset: str, mode: str):
        """Start trading for specific asset and mode."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        valid_modes = ['paper', 'live']
        
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        if mode not in valid_modes:
            raise HTTPException(status_code=400, detail=f"Invalid mode. Must be one of: {valid_modes}")
        
        try:
            # Update runtime to start trading for this asset
            runtime.start_asset_trading(asset.upper(), mode)
            
            # Log activity
            log_activity(asset.upper(), f"Starting {mode} trading...", "info")
            
            # If paper trading, initialize paper trader and start trading engine
            if mode == "paper" and get_paper_trader:
                paper_trader = get_paper_trader(asset)
                print(f"\n[START] {asset.upper()} Paper Trading Started")
                print(f"[BALANCE] Initial Balance: ${paper_trader.balance:.2f}")
                print(f"[STATUS] Paper trading is now ACTIVE")
                
                # Log more detailed activity
                log_activity(asset.upper(), f"Paper trading started - Balance: ${paper_trader.balance:.2f}", "success")
                
                # Start the trading engine in background
                if trading_engine:
                    # Use background task manager to start trading
                    success = background_tasks.start_trading_task(
                        asset,
                        trading_engine.start_trading
                    )
                    if success:
                        print(f"[ENGINE] Trading engine started for {asset.upper()}")
                        log_activity(asset.upper(), "Paper trading engine started", "success")
                    else:
                        print(f"[ENGINE] Trading engine already running for {asset.upper()}")
                        log_activity(asset.upper(), "Paper trading already active", "warning")
            
            return {
                "asset": asset,
                "mode": mode,
                "status": "started"
            }
        except Exception as exc:
            import traceback
            print(f"\n[ERROR] Error in start_asset_trading_endpoint: {exc}")
            print(f"Exception type: {type(exc).__name__}")
            traceback.print_exc()
            raise HTTPException(status_code=500, detail=f"Failed to start {asset} {mode} trading: {str(exc)}")

    @app.post("/asset/{asset}/stop/{mode}")
    async def stop_asset_trading_endpoint(asset: str, mode: str):
        """Stop trading for specific asset and mode."""
        valid_assets = ['crypto', 'futures', 'forex', 'forex_options']
        valid_modes = ['paper', 'live']
        
        if asset not in valid_assets:
            raise HTTPException(status_code=400, detail=f"Invalid asset. Must be one of: {valid_assets}")
        if mode not in valid_modes:
            raise HTTPException(status_code=400, detail=f"Invalid mode. Must be one of: {valid_modes}")
        
        try:
            runtime.stop_asset_trading(asset.upper(), mode)
            
            # Stop the trading engine
            if mode == "paper" and trading_engine:
                background_tasks.stop_trading_task(asset)
                print(f"[ENGINE] Trading engine stopped for {asset.upper()}")
                log_activity(asset.upper(), "Paper trading engine stopped", "info")
                
            return {
                "asset": asset,
                "mode": mode,
                "status": "stopped"
            }
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"Failed to stop {asset} {mode} trading: {exc}")

    return app


app = create_app()
# reload server


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("tradingbot.ui.app:app", host="127.0.0.1", port=8000, reload=True)
