"""Route handlers for the Trading Bot UI."""

__all__ = []
