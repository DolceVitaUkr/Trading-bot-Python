import sys
import os
print("--- sys.path ---")
print(sys.path)
print("\n--- PYTHONPATH environment variable ---")
print(os.environ.get('PYTHONPATH'))
