"""
Convenience script to run the trading bot from the repository root.
"""
from tradingbot.__main__ import main

if __name__ == "__main__":
    main()
